package com.viomi.vmuilibs;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

public class VButton extends View {
    public VButton(Context context) {
        super(context);
    }

    public VButton(Context context, @androidx.annotation.Nullable @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public VButton(Context context, @androidx.annotation.Nullable @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
